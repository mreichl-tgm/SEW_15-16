/**
 * @author mreichl
 * Tests our Register class
 */

public class Au05 {
	
	public static void main(String[] args) {
		Register r = new Register();
	}
	
}