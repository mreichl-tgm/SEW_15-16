package au01_reichl;

/**
 * @author Markus Reichl
 * @version 2015-09-14
 */

public class Au01 {
    public static void main(String[] args) {
        //Controller c = new Controller();
    	GUIController gc = new GUIController();
    }
}