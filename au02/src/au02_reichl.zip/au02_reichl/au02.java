package au02_reichl;

/**
 * @author mreichl
 * Tests our Register class
 */

public class au02 {
	public static void main(String[] args) {
		Register r = new Register();
	}

}