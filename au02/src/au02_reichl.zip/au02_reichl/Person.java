package au02_reichl;

/*
 * @author mreichl
 * Handles a person
 */

public class Person {
	protected String vname;
	protected String lname;
	
	public Person(String vname, String lname) {
		this.vname = vname;
		this.lname = lname;
	}
}